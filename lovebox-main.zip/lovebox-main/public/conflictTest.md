This is my conflict test text :)

Now I'm committing a change from Github.

Yet another change from Github. Changed line from dev. environment and Github.

Let's make some more changes / now making changes with VIM from the console.

Merged conflict in the console.
